Join Tech To Bangla YouTube Channel For Latest Videos And Secret Tech Trick For Free. https://www.youtube.com/c/TechToBangla1

RDP Windows

Create RDP Windows Ram 7GB 2 Core Cpu With Github

Press the Fork Button to create RDP (For Android/HP Users Please Use Desktop Mode). 
visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN Inside this Repo Go to Settings > Secrets > New repository secret contents 
Name: Enter NGROK_AUTH_TOKEN Contents Value: Visit https://dashboard.ngrok.com/auth/your-authtoken Copy And Paste in value Press Add secret 
Go to Action > FREE RDP > Run Refresh Web workflow and go to FREE RDP > build 
Press Down arrow key "RDP INFO LOGIN" To Get IP, User, Password.
